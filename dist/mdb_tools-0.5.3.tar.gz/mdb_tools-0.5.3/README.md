# HIDS-Capstone
 
Notebook with instructions & examples: [MDB Tools](https://github.com/nelsonwmoore/HIDS-Capstone/blob/main/mdb_tools_notebook.ipynb)
